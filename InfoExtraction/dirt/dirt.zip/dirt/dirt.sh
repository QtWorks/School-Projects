python dirt.py corpus.txt test.txt 5
