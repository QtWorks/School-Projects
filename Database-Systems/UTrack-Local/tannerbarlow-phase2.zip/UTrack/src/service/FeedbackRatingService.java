package service;

import static model.Columns.DISABLE_FK;
import static model.Columns.IDPOI;
import static model.Columns.MARKEDUSER;
import static model.Columns.MARKINGUSER;
import static model.Columns.RATING;

import cs5530.Connector;
import model.FeedbackRatingRecord;
import model.FeedbackRecord;
import model.POIRecord;
import model.UserRecord;
import model.VisitRecord;

/*
 * MarkedUser,POI,Rating,MarkingUser
 */
public class FeedbackRatingService {
	
	Connector con;

	public FeedbackRatingService(Connector con) {
		this.con = con;
	}
	
	public void insertFeedbackRating(FeedbackRatingRecord fr) {
		String sql = "INSERT INTO `cs5530db53`.`FeedbackRating` " + 
			"(`" + MARKINGUSER + "`,`" + MARKEDUSER + "`,`" + IDPOI + "`,`" + RATING +"`) VALUES "
			+ "('" + fr.getMarkingUser().getLogin()  + "','"
			+ fr.getFeedback().getUser().getLogin() + "',"
			+ fr.getFeedback().getPoi().getId() + ","
			+ fr.getRating() + ");";
		try{
			int result = con.stmt.executeUpdate(DISABLE_FK);
			int result2 = con.stmt.executeUpdate(sql);
		}
		catch(Exception e){
			String message = e.getMessage();
			if(message.contains("Duplicate")){
				System.out.println("It looks like you have already rated this review");
				System.out.println("This rating cannot be changed or updated.");
			}
			else{
				System.out.println("Cannot execute the query");
			}
		}
	}

}
