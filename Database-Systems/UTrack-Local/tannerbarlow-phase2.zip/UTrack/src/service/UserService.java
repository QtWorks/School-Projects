package service;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;

import cs5530.Connector;
import model.POIRecord;
import model.UserRecord;

import static model.Columns.*;

/*
 * Login,Name,Password,Address,Phone
 */
public class UserService {
	
	private Connector con;
		
	public UserService() {}

	public UserService(Connector con) {
		this.con = con;
	}


	public ArrayList<UserRecord> getUsers(String sql){
		ResultSet rs = null;
		ArrayList<UserRecord> users = new ArrayList<UserRecord>();
		try{
			rs = con.stmt.executeQuery(sql);
			while(rs.next()){
				UserRecord ur = new UserRecord();
				ur.setLogin(rs.getString(LOGIN));
				ur.setName(rs.getString(NAME));
				ur.setPassword(rs.getString(PASSWORD));
				ur.setPhone(rs.getString(PHONE));
				ur.setAddressId(rs.getInt(ADDRESS));
				ur.setAdmin(rs.getBoolean(IS_ADMIN));
				users.add(ur);
			}			
			rs.close();
		}
		catch(Exception e){
			System.out.println("cannot execute the query");
		}
		finally
	 	{
	 		try{
	 		if (rs!=null && !rs.isClosed())
	 			rs.close();
	 		}
	 		catch(Exception e)
	 		{
	 			System.out.println("cannot close resultset");
	 		}
	 	}
		AddressService as = new AddressService(con);
		for(UserRecord user : users){
			user.setAddress(as.getAddressById(user.getAddressId()));
		}
		return users;
	}
	
	public ArrayList<UserRecord> getUsersOneDegreeAway(UserRecord u1){
		String sql = "Select * from User where login in (" +
				"Select u2.login from User u1, User u2, Favorite f1, Favorite f2" +
				" where u1.login = f1.user" +
				" and u2.login = f2.user" +
				" and u1.login != u2.login" +
				" and f1.idpoi = f2.idpoi" +
				" and u1.login like '" + u1.getLogin() + "');";
		return getUsers(sql);
	}
	
	private boolean getBoolean(String sql) {
		ResultSet rs = null;
		try{
			rs = con.stmt.executeQuery(sql);
			while(rs.next()){
				return rs.getBoolean(1);
			}			
			rs.close();
		}
		catch(Exception e){
			System.out.println("cannot execute the query");
		}
		finally
	 	{
	 		try{
	 		if (rs!=null && !rs.isClosed())
	 			rs.close();
	 		}
	 		catch(Exception e)
	 		{
	 			System.out.println("cannot close resultset");
	 		}
	 	}
		return false;
	}

	public ArrayList<UserRecord> getUsersByFavorite(POIRecord favorite){
		String sql = "Select * from User u, Favorite f where u.login = f.user and f.idpoi = " + favorite.getId();
		return getUsers(sql);
	}


	public boolean isValidPassword(String login, String password) {
		return getUserByLogin(login).getPassword().equals(password);
	}
	
	public UserRecord getUserByLogin(String login){
		ArrayList<UserRecord> results = getUsers("select * from User where login = '" + login + "'" );
		if(results.size() > 0)
			return results.get(0);
		return null;
	}

	public boolean isAvailableLogin(String login) {
		return getUserByLogin(login) == null;
	}

	public void insertUser(UserRecord ur) {
		String sql = "INSERT INTO `cs5530db53`.`User` (`login`, `name`, `password`, `phone`, `address`, `isAdmin`) "
				+ "VALUES ('" + ur.getLogin() + "', '"
				+ ur.getName() + "', '" 
				+ ur.getPassword() + "', "
				+ ur.getPhone() + ", " 
				+ ur.getAddress().getId() + ", " 
				+ ur.isAdmin() + ");";
		try{
			int result = con.stmt.executeUpdate(DISABLE_FK);
			int result2 = con.stmt.executeUpdate(sql);
		}
		catch(Exception e){
			System.out.println("cannot execute the query");
		}
	}

	public ArrayList<UserRecord> getUsersByPOI(POIRecord poi) {
		String sql = "Select * from User u, Visit v where u.login = v.user and v.idpoi = " + poi.getId() + ";";
		return getUsers(sql);
	}

	public ArrayList<UserRecord> getAllUsers() {
		String sql = "Select * from User";
		return getUsers(sql);
	}

	public ArrayList<UserRecord> getTopUsers(int n, int choice) {
		String orderBy = "";
		if(choice == 1){
			orderBy += ", (select u2.login,(sum(t.trusted = 1)-sum(t.trusted = 0)) as tValue " + 
					" from Trusted t, User u2 " +
					" where t.marked_user = u2.login " +
					" group by u2.login) as tTable " +
					" where u1.login = tTable.login " +
					" order by tTable.tValue ";
		}else if(choice == 2){
			orderBy += "order by (select avg(fr.rating) " +
						" from FeedbackRating fr " +
						"where fr.marked_user like u1.login) ";
		}
		String sql = "Select * from User u1 " + orderBy + " DESC LIMIT " + n + ";";
		return getUsers(sql);
	}

	
	


}
