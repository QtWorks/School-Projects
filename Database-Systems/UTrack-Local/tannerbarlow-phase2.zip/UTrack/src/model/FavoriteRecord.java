package model;

public class FavoriteRecord {

	UserRecord user;
	POIRecord poi;
	
	public UserRecord getUser() {
		return user;
	}

	public void setUser(UserRecord user) {
		this.user = user;
	}

	public POIRecord getPoi() {
		return poi;
	}

	public void setPoi(POIRecord poi) {
		this.poi = poi;
	}

	public FavoriteRecord() {

	}

}
