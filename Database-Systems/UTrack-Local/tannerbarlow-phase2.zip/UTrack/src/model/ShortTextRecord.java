package model;

public class ShortTextRecord {
	
	VisitRecord visit;
	String text;

	public VisitRecord getVisit() {
		return visit;
	}

	public void setVisit(VisitRecord visit) {
		this.visit = visit;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public ShortTextRecord() {}

}
