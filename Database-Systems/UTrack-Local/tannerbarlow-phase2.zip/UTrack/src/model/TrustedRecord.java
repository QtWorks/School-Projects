package model;

public class TrustedRecord {

	public TrustedRecord() {

	}

}
